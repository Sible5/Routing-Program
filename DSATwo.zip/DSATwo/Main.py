# Author: Alex Sible Student ID: #000972826
import HashTable
import DistanceTableRead
import Truck
import datetime

format_string = "%m-%d-%Y %H:%M:%S"
distanceList = DistanceTableRead.distances
hubAddresses = DistanceTableRead.hubs

truckOne = Truck.truckOneData
truckTwo = Truck.truckTwoData
truckThree = Truck.truckThreeData

truckOneMaster = Truck.truckOne
truckTwoMaster = Truck.truckTwo
truckThreeMaster = Truck.truckThree


firstTruck = Truck.firstTruck
secondTruck = Truck.secondTruck
thirdTruck = Truck.thirdTruck

truckOneDists = []
truckTwoDists = []
truckThreeDists = []

packageLog = {}
packageLoadedLog = {}

sortedOne = []
sortedTwo = []
sortedThree = []

truckDeliveryIndexes = []
packageIDDeliveryIDDict = {}
truckReturnLog = {}

truckDrivenTotal = 0

# Runtime O(N)
# This is the main portion that the user would see. It prints out the information for the package chosen, at the time chosen. If the package has been delivered it will also display which truck it was delivered on.
def displayPackageInfo(packageNum, packageTime):
    print("Here is the information on package " + packageNum + ":")
    pkg = HashTable.hashed.getPackage(int(packageNum))
    print("Package ID:", pkg[0])
    print("Package Delivery Address:", pkg[1])
    print("Package Delivery City:", pkg[2])
    print("Package Delivery State:", pkg[3])
    print("Package Delivery Zip Code:", pkg[4])
    print("Package Delivery Deadline:", pkg[5])
    print("Package Delivery Weight:", pkg[6])

    checkTime = datetime.datetime.now()

    # this is the time we are checking Against
    (Hour, Minute) = packageTime.split(":")
    checkTime = checkTime.replace(hour=int(Hour), minute=int(Minute), second=00, microsecond=99)

    # this is the time the package left the building
    leaveTime = packageLoadedLog[pkg[0]]

    # This is the time time the package was delivered
    deliveryTime = packageLog[pkg[0]]

    newDeliveryTime = datetime.datetime.strptime(deliveryTime, format_string)
    newLeaveTime = datetime.datetime.strptime(leaveTime, format_string)

    # This portion compares the three times to the inputted time and chooses the correct status to display
    if newDeliveryTime > checkTime and checkTime > newLeaveTime:
        pkg[7] = "In Transit"
    if newDeliveryTime < checkTime:
        pkg[7] = "Delivered"

    if checkTime < newLeaveTime:
        pkg[7] = "At Hub"

    print("Package Delivery Status:", pkg[7])
    if pkg[7] == "Delivered":
        delTime = packageLog[pkg[0]]
        (delDateOnly,delTimeOnly) = delTime.split(" ")
        print("Package Delivered at:", delTimeOnly)


    if pkg[0] in truckOneMaster:
        print("On Truck: 1")
    if pkg[0] in truckTwoMaster:
        print("On Truck: 2")
    if pkg[0] in truckThreeMaster:
        print("On Truck: 3")
    packageStatusCheck()

# Runtime O(1)
# This function does the math to set the delivery time. If the trucks were changed to a different speed you could change it here.
def getTimeChange(currentTime, milesDriven):
    speed = 18.0
    milesDriven = float(milesDriven)
    fractionOfHours = milesDriven / speed
    minutes = fractionOfHours * 60
    newTime = currentTime + datetime.timedelta(minutes=minutes)
    return newTime


# This function creates the dictionary that holds the delivery addresses index in the lookup Table.
# Runtime O(N^2)
def createDeliveryIndexList(packageData):
    for item in packageData:
        address = item[1]
        ID = int(item[0])
        for i in range(len(hubAddresses)):
            if hubAddresses[i][2] == address:
                truckDeliveryIndexes.append(i)

                packageIDDeliveryIDDict[ID] = i
            i += 1

#This function creates the logs for all the packages each time it is called Runtime O(N)
#This is where the sorted list is sent and the actual time changing is being done. It reads in the list of distances driven, the list of packages, and the truck.
def createLogs(milesList, packageIDList, truck):
    firstPackage = int(packageIDList[0])
    firstDel = packageIDDeliveryIDDict[firstPackage]
    firstMiles = float(distanceList[firstDel][0])
    milesList.insert(0, firstMiles)
    newTotal = 0.0
    firstTime = truck.getTime()
    # This loop sets the time that the packages were loaded onto the truck Runtime: O(N)
    # It also increments the total miles driven, and the delivery time.

    for i in range(len(packageIDList)):
        packageID = packageIDList[i]

        loadedTime = firstTime.strftime(format_string)
        packageLoadedLog[packageID] = loadedTime
        newTotal += float(milesList[i])
        milesDriven = milesList[i]
        newTime = getTimeChange(truck.getTime(), milesDriven)
        truck.setTime(newTime)
        newTime = newTime.strftime(format_string)
        packageLog[packageID] = newTime

    finalPackage = packageIDDeliveryIDDict[int(packageIDList[-1])]
    backToHubDist = distanceList[finalPackage][0]

    newTotal += float(backToHubDist)
    newTime = getTimeChange(truck.getTime(), backToHubDist)
    newTime = newTime.strftime(format_string)
    truckReturnLog[truck.getTruckID()] = newTime

    truck.setMilesDriven(newTotal)

# This is a function to display all the package info at a given time, typically for development/testing.
# Runtime O(N)
def displayAllInfo(packageTime):
    checkTime = datetime.datetime.now()

    (Hour, Minute) = packageTime.split(":")
    checkTime = checkTime.replace(hour=int(Hour), minute=int(Minute), second=00, microsecond=99)
    print("ALL PACKAGE INFORMATION  CHECKED AT:", packageTime)
    print("------------------------------------------------")
    # printing out all package info Runtime O(N)
    for i in range(1, 41):
        statusString = ""
        pkg = HashTable.hashed.getPackage(i)
        packageID = pkg[0]
        leaveTime = packageLoadedLog[packageID]

        deliveryTime = packageLog[packageID]
        (deliveryDateOnly, deliveryTimeOnly) = deliveryTime.split(" ")
        # These lines change what I stored as a string back into a Datetime object so it can be compared.
        newDeliveryTime = datetime.datetime.strptime(deliveryTime, format_string)
        newLeaveTime = datetime.datetime.strptime(leaveTime, format_string)
        if newDeliveryTime > checkTime and checkTime > newLeaveTime:
            statusString = "In Transit"
        if newDeliveryTime < checkTime:
            statusString = "Delivered"

        if checkTime < newLeaveTime:
            statusString = "At Hub"
        if statusString == "Delivered":
            print("Package ID:", packageID, "  Status:", statusString, "  Delivered at:", deliveryTimeOnly)
        else:
            print("Package ID:", packageID, "  Status:", statusString)

    packageStatusCheck()

# Runtime O(1)
# This is where the interface is really housed. It reads the information from the user and has some light error checking. It calls itself again if the user inputs an incorrect character.
def packageStatusCheck():
    lookupPackage = input("Would you like to lookup a package? (Enter all to see data on all the packages) y/n: ")
    correctInput = False
    if lookupPackage == 'y':
        packageNum = input("Which package would you like to check? e.g. 15: ")
        if int(packageNum) > 40 or int(packageNum) < 1:
            packageNum = input("Please enter a number between 1 and 40: ")
        print("Please use 24 hour time. I.E. 2:00  PM = 14:00")
        packageTime = input("At what time would you like to check the status? e.g. 9:30: ")
        correctInput = True
        displayPackageInfo(packageNum, packageTime)

    elif lookupPackage == 'n':
        correctInput = True
        print("Thank you.")
    elif lookupPackage == 'all':
        print("Please use 24 hour time. I.E. 2:00  PM = 14:00")
        packageTime = input("At what time would you like to check the status? e.g. 9:30: ")
        correctInput = True
        displayAllInfo(packageTime)
    if correctInput == False:
        print("Please enter y or n.")
        packageStatusCheck()


# This is the main algorithm. It reads in the list of package IDs, and sorts it using a nearest neighbor algorithm.
# The function takes two arguments, the list of package IDs, and the truck, so that the delivery miles and time can be tracked.
# It starts by removing the first item in the list. Then it finds the distance from the first package to the rest of the packages. When the nearest package ID is found it moves that package to
# the front of the list and calls the function again. It adds the removed item to a separate sorted list.
# It is recursive so the total Runtime is O(N^2)
def sortList(packageList, truckID):
    StepDict = {}
    currentPackage = packageList[0]
    if truckID == 1:
        sortedOne.append(currentPackage)
    if truckID == 2:
        sortedTwo.append(currentPackage)
    if truckID == 3:
        sortedThree.append(currentPackage)

    packageList.pop(0)

    currentDeliveryIndex = packageIDDeliveryIDDict[int(currentPackage[0])]

    # This algorithm is what inputs the remaining packages into a list with the distance to the next closest destination. Runtime O(N)

    for i in range(len(packageList)):
        packageID = packageList[i][0]
        delID = packageIDDeliveryIDDict[int(packageID)]
        delDistance = distanceList[delID][currentDeliveryIndex]
        if delDistance == '':
            delDistance = distanceList[currentDeliveryIndex][delID]
        elif currentDeliveryIndex == delID:
            delDistance = 0.0
        StepDict[packageID] = float(delDistance)

    if len(packageList) > 1:
        nextPackageID = min(StepDict, key=StepDict.get)

        if truckID == 1:
            truckOneDists.append(StepDict[nextPackageID])
        if truckID == 2:
            truckTwoDists.append(StepDict[nextPackageID])
        if truckID == 3:
            truckThreeDists.append(StepDict[nextPackageID])

    if len(packageList) == 1:
        nextPackageID = packageID

        if truckID == 1:
            truckOneDists.append(StepDict[nextPackageID])
        if truckID == 2:
            truckTwoDists.append(StepDict[nextPackageID])
        if truckID == 3:
            truckThreeDists.append(StepDict[nextPackageID])

    for item in packageList:
        if item[0] == str(nextPackageID):
            packageList.remove(item)
            packageList.insert(0,item)

    if len(packageList) >= 1:

        sortList(packageList, truckID)

# Runtime 0(1)
# This is here to change the incorrect address. I call this function after the time specified to ensure the package is not changed too early.
def correctAddress():
    pkg = HashTable.hashed.getPackage(9)
    pkg[1] = "410 S State St"
    pkg[3] = "UT"
    pkg[2] = "Salt Lake City"
    pkg[4] = "84111"

# this section is where all of the functions are called. There are 3 for loops so the total runtime would be O(3N) or O(N)
# the time statements set the time for the second and third trucks, as they leave earlier in the day. The first truck was set to leave at 8PM in the truck file.
# this also is where the interface begins.
class Main:
    # setting up index lists with functions

    correctAddress()

    createDeliveryIndexList(truckOne)

    createDeliveryIndexList(truckTwo)

    createDeliveryIndexList(truckThree)

    sortList(truckOne, 1)
    sortList(truckTwo, 2)
    sortList(truckThree, 3)

    list1 = []
    list2 = []
    list3 = []

    for item in sortedOne:
        list1.append(item[0])
    for item in sortedTwo:
        list2.append(item[0])
    for item in sortedThree:
        list3.append(item[0])
    ###
    # These lines set the leave times for each truck. It also corrects the faulty address
    # I held Truck 2 until 9:20 for the packages that were delayed on the plane.
    # I held Truck 3 until 11:00 to ensure truck One had returned.

    time = datetime.datetime.now()
    time = time.replace(hour=9, minute=20, second=00)
    timeThird = time.replace(hour=11, minute=00, second=00)
    secondTruck.setTime(time)
    thirdTruck.setTime(timeThird)

    createLogs(truckOneDists, list1, firstTruck)
    createLogs(truckTwoDists, list2, secondTruck)
    createLogs(truckThreeDists, list3, thirdTruck)

    truckDrivenTotal = float(firstTruck.getMilesDriven()) + float(secondTruck.getMilesDriven()) + float(
        thirdTruck.getMilesDriven())
    print("Welcome to WGUPS Package Tracking Program!")
    print("Total Miles Driven:", truckDrivenTotal)

    packageStatusCheck()
