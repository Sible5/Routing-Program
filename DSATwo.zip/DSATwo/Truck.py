import Package
import HashTable
import DistanceTableRead
from datetime import datetime

distanceList = DistanceTableRead.distances
hubAddresses = DistanceTableRead.hubs

truckOne = ['15','13','14','1','16','19','20','27','29','30','31','34','35','37','40']
truckTwo = ['22','3','5','12','6','17','18','2','25','28','32','36','38']
truckThree = ['4','7','8','9','10','11','21','23','24','26','33','39']

truckOneData = []
truckTwoData = []
truckThreeData = []

packages = Package.allPackages

date = datetime.now()
leaveTime = date.replace(hour=8, minute=00,second=00)

# Below is the truck class with getters and setters. This makes the trucks highly customizable
class Truck:
    def __init__(self,speed,currentLocation,nextLocation,time,milesDriven,transitStatus,listOfPackages,truckID):
        self.speed = speed
        self.currentLocation = currentLocation
        self.nextLocation = nextLocation
        self.time = time
        self.milesDriven = milesDriven
        self.transitStatus = transitStatus
        self.listOfPackages = listOfPackages
        self.truckID = truckID
    def getSpeed(self):
        return self.speed

    def getCurrentLocation(self):
        return self.currentLocation

    def getNextLocation(self):
        return self.nextLocation

    def getTime(self):
        return self.time

    def getMilesDriven(self):
        return self.milesDriven

    def getTransitStatus(self):
        return self.transitStatus

    def getListOfPackages(self):
        return self.listOfPackages

    def getTruckID(self):
        return self.truckID


    def setTime(self,time):
        self.time = time

    def setMilesDriven(self,milesDriven):
        self.milesDriven = milesDriven

    def setTransitStatus(self,transitStatus):
        self.transitStatus = transitStatus

    def setListOfPackages(self,listOfPackages):
        self.listOfPackages = listOfPackages

    def setTruckID(self,truckID):
        self.truckID = truckID

# Runtime O(3N) or O(N)
# This is a function that manually loads each truck with the packages I decided. in the future this process could be automated.
def loadTrucks():
    for item in truckOne:
        loaded = HashTable.hashed.getPackage(int(item))
        truckOneData.append(loaded)
    for item in truckTwo:
        loaded = HashTable.hashed.getPackage(int(item))
        truckTwoData.append(loaded)
    for item in truckThree:
        loaded = HashTable.hashed.getPackage(int(item))
        truckThreeData.append(loaded)



firstTruck = Truck(18.0,'At Hub','TBD',leaveTime,0.0,'At Hub',truckOne,1)
secondTruck = Truck(18.0,'At Hub','TBD',leaveTime,0.0,'At Hub',truckTwo,2)
thirdTruck = Truck(18.0,'At Hub','TBD',leaveTime,0.0,'At Hub',truckThree,3)

loadTrucks()