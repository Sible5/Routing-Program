#Reading in the csv data from the distance table

import csv

distances = []
hubs = []

# Runtime O(N)
with open('HubDistanceOnlyTable.csv') as distanceTableFile:
    readCSV = csv.reader(distanceTableFile, delimiter = ',')
    distances = []
    for row in readCSV:
        distances.append(row)

# Runtime O(N)
with open('NameAddressTable.csv') as nameFile:
    readNameCSV = csv.reader(nameFile,delimiter = ',')
    for row in readNameCSV:
        hubs.append(row)

