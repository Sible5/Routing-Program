import csv

allPackages = []

# Below is the package class. along with getters and setters which in the future could make the package data very customizable.
class Package:
    def __init__(self, packageID, deliveryAddress, deliveryCity, deliveryState, deliveryZip, deliveryDeadline,
                 packageWeight, deliveryStatus):
        self.packageID = packageID
        self.deliveryAddress = deliveryAddress
        self.deliveryCity = deliveryCity
        self.deliveryState = deliveryState
        self.deliveryZip = deliveryZip
        self.deliveryDeadline = deliveryDeadline
        self.packageWeight = packageWeight
        self.deliveryStatus = deliveryStatus

    def getPackageID(self):
        return self.packageID

    def getDeliveryAddress(self):
        return self.deliveryAddress

    def getDeliveryCity(self):
        return self.deliveryCity

    def getDeliveryState(self):
        return self.deliveryState

    def getDeliveryZip(self):
        return self.deliveryZip

    def getDeliveryDeadline(self):
        return self.deliveryDeadline

    def getPackageWeight(self):
        return self.packageWeight

    def getDeliveryStatus(self):
        return self.deliveryStatus

    def setPackageID(self, packageID):
        self.packageID = packageID

    def setDeliveryAddress(self, deliveryAddress):
        self.deliveryAddress = deliveryAddress

    def setDeliveryCity(self, deliveryCity):
        self.deliveryCity = deliveryCity

    def setDeliveryState(self, deliveryState):
        self.deliveryState = deliveryState

    def setDeliveryZip(self, deliveryZip):
        self.deliveryZip = deliveryZip

    def setDeliveryDeadline(self, deliveryDeadline):
        self.deliveryDeadline = deliveryDeadline

    def setPackageWeight(self, packageWeight):
        self.packageWeight = packageWeight

    def setDeliveryStatus(self, deliveryStatus):
        self.deliveryStatus = deliveryStatus

    # Runtime O(N)
    # This function reads the .csv file provided and moves all the information into a list so that it is easier to parse into the hash table.
def makePackageList():
    with open('WGUpackages.csv') as packageFile:
        readCSV = csv.reader(packageFile, delimiter=',')
        for packageId, delAddress, delCity, delState, delZip, delDead, pkgWeight, delStatus in readCSV:
            allPackages.append(Package(packageId, delAddress, delCity, delState, delZip, delDead, pkgWeight, delStatus))
    return allPackages


makePackageList()
