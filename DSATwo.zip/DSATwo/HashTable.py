

import Package

packages = Package.allPackages


#The hash table is self adjusting as you can edit the information that is stored with each pacakge. It uses the package ID as the key
class HashTable:
    def __init__(self):
        self.size = 48
        self.map = [None] * self.size


    #Complexity is O(1)
    def _get_hash(self, key):

        return int(key) % self.size

    #Insert a new package
    #Complexity is O(N)
    def add(self,key,ID,address,deadline,city,zip,weight,status):
        key_hash = self._get_hash(key)
        status = 'at Hub'
        key_value = [key,ID,address,deadline,city,zip,weight,status]

        if self.map[key_hash] is None:
            self.map[key_hash] = list([key_value])
            return True
        else:
            for item in self.map[key_hash]:
                if item[0] == key:
                    return True
            self.map[key_hash].append(key_value)
            return True

    #Worst Case Complexity is O(N)
    def getPackage(self,key):
        key_hash = self._get_hash(key)

        if self.map[key_hash] is not None:
            for item in self.map[key_hash]:
                if int(item[0]) == key:

                    return item

        else:
            return None

hashed = HashTable()
#This is adding all the items into the hash table via the CSV file provided. Runtime O(N)
for item in packages:
    hashed.add(item.getPackageID(),item.getDeliveryAddress(),item.getDeliveryCity(),item.getDeliveryState(),item.getDeliveryZip(),item.getDeliveryDeadline(),item.getPackageWeight(),item.getDeliveryStatus())


